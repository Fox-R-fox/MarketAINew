import asyncio, json, logging
from typing import Dict, List
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from utils import is_market_open, now_ist, current_minute_bar
from broker import PaperBroker, ZerodhaKiteBroker, AbstractBroker, Position
from scanner import top10_buy_candidates, qty_for_wallet
from strategy import calc_sl_tp

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
log = logging.getLogger("app")

app = FastAPI(title="MarketAIHub Server v3.7")

# CORS for localhost dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Settings(BaseModel):
    api_key: str = ""
    access_token: str = ""
    paper_capital: float = 100000.0
    auto_enabled: bool = True
    max_positions: int = 5
    risk_per_trade: float = 0.02
    prefer_options: bool = True
    use_bo_co: bool = True
    only_index_options: bool = True
    only_weekly: bool = False
    option_kind: str = "BOTH"
    simulate_closed_market: bool = True
    sim_vol_mult: float = 1.0
    sim_tick_seconds: float = 1.0
    zerodha_connected: bool = False

SETTINGS = Settings()

# State
BROKER: AbstractBroker = PaperBroker(starting_cash=SETTINGS.paper_capital)
OPEN_SYMBOLS: Dict[str, dict] = {}
QUOTES: Dict[str, float] = {}
CANDIDATES: List[dict] = []
LAST_EXIT_BAR: Dict[str, int] = {}
ACTION_LOG: List[dict] = []
KITE_DATA = None
SIM_STATE: Dict[str, dict] = {}
PERF: List[dict] = []
CUM_PNL: float = 0.0

def log_event(type_: str, msg: str, **extra):
    ev = {'t': now_ist().isoformat(), 'type': type_, 'msg': msg}
    ev.update(extra)
    ACTION_LOG.append(ev)
    if len(ACTION_LOG) > 500:
        del ACTION_LOG[:len(ACTION_LOG)-500]

def _seed_sim_for_symbol(symbol: str, ltp: float):
    """Seed simulation state for a symbol using ATR from Zerodha historical (if available)."""
    from simulator import SimState
    try:
        if KITE_DATA is None:
            sigma = 0.0015
            SIM_STATE[symbol] = {'state': SimState(last=ltp, sigma=sigma, dt=1.0)}
            return
        # Need instrument token
        from scanner import token_for
        token = token_for(symbol)
        if token == 0:
            SIM_STATE[symbol] = {'state': SimState(last=ltp, sigma=0.0015, dt=1.0)}
            return
        import datetime as dt
        end = now_ist()
        start = end - dt.timedelta(minutes=60)
        candles = KITE_DATA.historical_data(token, start, end, interval='minute')
        if candles:
            atrs = []
            for c in candles[-30:]:
                h = float(c.get('high', 0)); l = float(c.get('low', 0)); cl = float(c.get('close', 0) or ltp or 1.0)
                if cl > 0:
                    atrs.append((h-l)/cl)
            atr = sum(atrs)/len(atrs) if atrs else 0.01
        else:
            atr = 0.01
        per_sec_sigma = max(atr / (60 ** 0.5), 0.0005)
        SIM_STATE[symbol] = {'state': SimState(last=ltp, sigma=per_sec_sigma, dt=1.0)}
    except Exception:
        SIM_STATE[symbol] = {'state': SimState(last=ltp, sigma=0.0015, dt=1.0)}

@app.get('/api/v1/health')
def health():
    return {'ok': True, 'market_open': is_market_open(), 'wallet': BROKER.wallet_balance(), 'broker': BROKER.name()}

@app.get("/api/v1/test_zerodha")
def test_zerodha():
    global KITE_DATA
    if KITE_DATA is None:
        return {"ok": False, "msg": "Not connected."}
    try:
        info = KITE_DATA.margins("equity")
        return {"ok": True, "margins": info}
    except Exception as e:
        return {"ok": False, "msg": str(e)}

@app.get("/api/v1/settings")
def get_settings():
    s = SETTINGS.dict()
    s["api_key"] = "***" if s["api_key"] else ""
    s["access_token"] = "***" if s["access_token"] else ""
    s["broker"] = BROKER.name()
    s["wallet"] = BROKER.wallet_balance()
    s["market_open"] = is_market_open()
    s["zerodha_connected"] = SETTINGS.zerodha_connected
    return s

class SaveSettings(BaseModel):
    api_key: str = ""
    access_token: str = ""
    paper_capital: float = 100000.0
    max_positions: int = 5
    risk_per_trade: float = 0.02
    prefer_options: bool = True
    use_bo_co: bool = True
    only_index_options: bool = True
    only_weekly: bool = False
    option_kind: str = "BOTH"
    simulate_closed_market: bool = True
    sim_vol_mult: float = 1.0
    sim_tick_seconds: float = 1.0

@app.post("/api/v1/save_settings")
def save_settings(body: SaveSettings):
    global BROKER, SETTINGS, KITE_DATA
    SETTINGS.api_key = body.api_key or ""
    SETTINGS.access_token = body.access_token or ""
    SETTINGS.paper_capital = float(body.paper_capital or 100000.0)
    SETTINGS.max_positions = int(body.max_positions or 5)
    SETTINGS.risk_per_trade = float(body.risk_per_trade or 0.02)
    SETTINGS.prefer_options = bool(body.prefer_options)
    SETTINGS.use_bo_co = bool(body.use_bo_co)
    SETTINGS.only_index_options = bool(body.only_index_options)
    SETTINGS.only_weekly = bool(body.only_weekly)
    SETTINGS.option_kind = body.option_kind if body.option_kind in ("CE","PE","BOTH") else "BOTH"
    SETTINGS.simulate_closed_market = bool(body.simulate_closed_market)
    SETTINGS.sim_vol_mult = float(body.sim_vol_mult or 1.0)
    SETTINGS.sim_tick_seconds = float(body.sim_tick_seconds or 1.0)

    # Try connect to Zerodha as data source
    SETTINGS.zerodha_connected = False
    KITE_DATA = None
    if SETTINGS.api_key and SETTINGS.access_token:
        try:
            from kiteconnect import KiteConnect  # type: ignore
            kite = KiteConnect(api_key=SETTINGS.api_key)
            kite.set_access_token(SETTINGS.access_token)
            _ = kite.margins("equity")
            KITE_DATA = kite
            SETTINGS.zerodha_connected = True
            log_event('info', 'Zerodha data connection: OK')
        except Exception as e:
            log_event('error', f'Zerodha data connection failed: {e}')

    # Execution broker
    if is_market_open() and SETTINGS.zerodha_connected:
        try:
            BROKER = ZerodhaKiteBroker(SETTINGS.api_key, SETTINGS.access_token)  # type: ignore
            BROKER.refresh()
            log_event('info', 'Execution broker set to Zerodha (market open)')
        except Exception as e:
            log_event('warn', f'Zerodha execution init failed: {e}; using Paper')
            BROKER = PaperBroker(starting_cash=SETTINGS.paper_capital)
    else:
        BROKER = PaperBroker(starting_cash=SETTINGS.paper_capital)
        why = 'market closed' if not is_market_open() else 'no/invalid creds'
        log_event('info', f'Execution broker set to Paper ({why})')

    return {"ok": True, "broker": BROKER.name(), "wallet": BROKER.wallet_balance(), "market_open": is_market_open(), "zerodha_connected": SETTINGS.zerodha_connected}

class AutoToggle(BaseModel):
    enable: bool

@app.post("/api/v1/auto_toggle")
def auto_toggle(body: AutoToggle):
    SETTINGS.auto_enabled = bool(body.enable)
    log_event('info', f"Auto mode {'enabled' if SETTINGS.auto_enabled else 'disabled'}")
    return {"ok": True, "auto_enabled": SETTINGS.auto_enabled}

@app.get("/api/v1/portfolio")
def portfolio():
    if hasattr(BROKER, "positions"):
        pos = [vars(p) for p in getattr(BROKER, "positions").values()]
    else:
        pos = []
    return {"positions": pos, "cash": BROKER.wallet_balance()}

@app.get("/api/v1/candidates")
def candidates():
    return {"candidates": CANDIDATES}

@app.websocket("/ws/live")
async def live(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            payload = {
                "t": now_ist().isoformat(),
                "market_open": is_market_open(),
                "settings": {
                    "auto_enabled": SETTINGS.auto_enabled,
                    "broker": BROKER.name(),
                    "max_positions": SETTINGS.max_positions,
                    "risk_per_trade": SETTINGS.risk_per_trade,
                    "filters": {
                        "only_index_options": SETTINGS.only_index_options,
                        "only_weekly": SETTINGS.only_weekly,
                        "option_kind": SETTINGS.option_kind,
                    }
                },
                "wallet": BROKER.wallet_balance(),
                "zerodha_connected": SETTINGS.zerodha_connected,
                "data_source": "zerodha" if KITE_DATA is not None else "none",
                "simulate_closed_market": SETTINGS.simulate_closed_market,
                "sim_vol_mult": SETTINGS.sim_vol_mult,
                "sim_tick_seconds": SETTINGS.sim_tick_seconds,
                "open_symbols": OPEN_SYMBOLS,
                "quotes": QUOTES,
                "events": ACTION_LOG[-50:],
                "perf": PERF[-500:],
                "cum_pnl": CUM_PNL,
            }
            await ws.send_text(json.dumps(payload, default=str))
            await asyncio.sleep(2.0)
    except WebSocketDisconnect:
        return

async def auto_loop():
    global QUOTES, CANDIDATES, LAST_EXIT_BAR, OPEN_SYMBOLS, BROKER, CUM_PNL, PERF
    while True:
        try:
            BROKER.refresh()
            wallet = BROKER.wallet_balance()

            # Ensure correct broker on market open/close boundaries
            live_should_be = is_market_open() and SETTINGS.api_key and SETTINGS.access_token
            if live_should_be and BROKER.name() != "zerodha":
                try:
                    BROKER = ZerodhaKiteBroker(SETTINGS.api_key, SETTINGS.access_token)  # type: ignore
                    BROKER.refresh()
                    log_event('info', 'Switched to Zerodha (market opened)')
                except Exception as e:
                    log.warning("Switch to Zerodha failed: %s", e)
            elif (not live_should_be) and BROKER.name() != "paper":
                BROKER = PaperBroker(starting_cash=SETTINGS.paper_capital)
                log_event('info', 'Switched to Paper (market closed)')

            # Refresh candidates using KITE_DATA if available
            cands = top10_buy_candidates(
                KITE_DATA if KITE_DATA is not None else (getattr(BROKER, "kite", None) if hasattr(BROKER, "kite") else None),
                wallet_cash=wallet,
                prefer_options=SETTINGS.prefer_options,
                index_only=SETTINGS.only_index_options,
                weekly_only=SETTINGS.only_weekly,
                option_kind=SETTINGS.option_kind,
            )
            CANDIDATES = [{
                "symbol": s, "ltp": float(ltp), "affordable": bool(meta.get("affordable", False)),
                "score": round(float(meta.get("score", 0.0)), 3),
                "oi_chg": round(float(meta.get("oi_chg", 0.0)), 4),
                "iv_chg": round(float(meta.get("iv_chg", 0.0)), 4),
                "long_buildup": bool(meta.get("long_buildup", False)),
                "lot_size": int(meta.get("lot_size", 1))
            } for (s, ltp, meta) in cands]

            if CANDIDATES:
                top = CANDIDATES[0]
                log_event('scan', f"Top pick {top['symbol']} LTP {top['ltp']} score {top['score']} affordable={top['affordable']}")

            # Trade (live or paper)
            if SETTINGS.auto_enabled:
                open_count = len(OPEN_SYMBOLS)
                slots = max(SETTINGS.max_positions - open_count, 0)
                bar_now = current_minute_bar()

                for row in CANDIDATES:
                    if slots <= 0:
                        break
                    s, ltp, affordable, lot = row["symbol"], row["ltp"], row["affordable"], int(row["lot_size"] or 1)
                    if s in OPEN_SYMBOLS:
                        log_event('skip', f'{s} already open')
                        continue
                    last_exit = LAST_EXIT_BAR.get(s, None)
                    if last_exit is not None and last_exit == bar_now:
                        log_event('skip', f'{s} blocked this bar (session control)')
                        continue
                    if not affordable:
                        log_event('skip', f'{s} not affordable')
                        continue

                    qty = qty_for_wallet(ltp, lot, wallet_cash=wallet, risk_perc=SETTINGS.risk_per_trade, sl_pct=0.30)
                    if qty < lot:
                        log_event('skip', f'{s} qty {qty} < lot {lot}')
                        continue

                    sl, tp = (round(ltp * (1 - 0.30), 2), round(ltp * (1 + 0.25), 2))
                    order = BROKER.place_market_order(s, "BUY", qty=qty, price_hint=ltp, sl=sl, tp=tp, use_bo_co=SETTINGS.use_bo_co)
                    if order.status == "FILLED":
                        OPEN_SYMBOLS[s] = {"entry": float(order.filled_price or ltp), "sl": sl, "tp": tp, "qty": order.qty, "lot_size": lot}
                        log_event('buy', f'BUY {s} qty {order.qty} @ ~{ltp} SL {sl} TP {tp} [{BROKER.name()}]')
                        slots -= 1
                    else:
                        log_event('error', f'Order rejected for {s}')

            # Quotes
            if (not is_market_open()) and SETTINGS.simulate_closed_market and OPEN_SYMBOLS:
                from simulator import gbm_tick
                for s, data in list(OPEN_SYMBOLS.items()):
                    last = data.get("last", data["entry"])
                    if s not in SIM_STATE:
                        _seed_sim_for_symbol(s, last)
                    st = SIM_STATE[s]['state']
                    st.dt = max(0.1, float(SETTINGS.sim_tick_seconds))
                    st.sigma = max(1e-5, float(st.sigma) * float(SETTINGS.sim_vol_mult))
                    newp = gbm_tick(st)
                    QUOTES[s] = newp
                    OPEN_SYMBOLS[s]["last"] = newp
            elif (KITE_DATA is not None) and OPEN_SYMBOLS:
                try:
                    q = KITE_DATA.quote([f"NFO:{s}" for s in OPEN_SYMBOLS.keys()])
                    QUOTES = {sym: float(data.get("last_price") or data.get("last_traded_price") or 0.0)
                              for exsym, data in q.items() for sym in [exsym.split(":")[-1]]}
                except Exception as e:
                    log.warning("quote failed: %s", e)
            else:
                # gentle drift fallback
                from random import random
                for s, data in list(OPEN_SYMBOLS.items()):
                    last = data.get("last", data["entry"])
                    drift = last * 0.002
                    newp = max(0.01, last + drift if random() > 0.5 else last - drift)
                    QUOTES[s] = newp
                    OPEN_SYMBOLS[s]["last"] = newp

            # Exits
            bar_now = current_minute_bar()
            for s, data in list(OPEN_SYMBOLS.items()):
                last = QUOTES.get(s, data["entry"])
                if last <= data["sl"] or last >= data["tp"]:
                    try:
                        p = Position(symbol=s, qty=data["qty"], avg_price=data["entry"], side="BUY", sl=data["sl"], tp=data["tp"], open_order_id="", open_time=now_ist().timestamp())
                        BROKER.close_position(p, last)  # type: ignore
                    except Exception as e:
                        log_event('error', f'Close failed {s}: {e}')
                    entry = data.get("entry", last)
                    qty = int(data.get("qty", 0) or 0)
                    pnl = (last - entry) * qty
                    del OPEN_SYMBOLS[s]
                    LAST_EXIT_BAR[s] = bar_now
                    try:
                        CUM_PNL += pnl
                        PERF.append({"t": now_ist().isoformat(), "pnl": float(CUM_PNL)})
                    except Exception:
                        pass
                    log_event('exit', f'Exit {s} @ {last} [{BROKER.name()}] PnL {pnl:.2f}', pnl=float(pnl))

            await asyncio.sleep(5.0)
        except Exception as e:
            log.error("auto_loop error: %s", e)
            log_event('error', f'Auto loop: {e}')
            await asyncio.sleep(3.0)

@app.on_event("startup")
async def on_start():
    asyncio.create_task(auto_loop())
