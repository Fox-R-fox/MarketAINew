
import React, { useEffect, useState } from 'react'

export default function LiveDataFeed({ children }){
  const [live, setLive] = useState(null)
  const [portfolio, setPortfolio] = useState(null)
  const [candidates, setCandidates] = useState(null)

  useEffect(()=>{
    const ws = new WebSocket(`ws://${window.location.host.replace(':5173', ':8000')}/ws/live`)

    ws.onmessage = (ev)=>{
      try{
        const d = JSON.parse(ev.data)
        setLive(d)
        // Pull portfolio and candidates on each ping (cheap in dev; consider rate limiting in prod)
        fetch('/api/v1/portfolio').then(r=>r.json()).then(setPortfolio).catch(()=>{})
        fetch('/api/v1/candidates').then(r=>r.json()).then(setCandidates).catch(()=>{})
      }catch(e){
        console.error('WS parse error', e)
      }
    }
    ws.onclose = ()=>{
      console.warn('WS closed')
    }
    return ()=> ws.close()
  },[])

  if(!live){
    return <div className="card">Connecting to live feed...</div>
  }

  return children({ live, portfolio, candidates })
}
