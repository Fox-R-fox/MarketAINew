
import asyncio, json, logging, os
from typing import Dict, List
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from utils import is_market_open, now_ist, current_minute_bar
from broker import PaperBroker, ZerodhaKiteBroker, AbstractBroker
from scanner import top10_buy_candidates, qty_for_wallet
from strategy import calc_sl_tp

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
log = logging.getLogger("app")

app = FastAPI(title="MarketAIHub Server")

# CORS for localhost dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Settings(BaseModel):
    api_key: str = ""
    access_token: str = ""
    paper_capital: float = 100000.0
    auto_enabled: bool = True
    max_positions: int = 5
    risk_per_trade: float = 0.02
    prefer_options: bool = True
    use_bo_co: bool = True
    only_index_options: bool = True
    only_weekly: bool = False
    option_kind: str = "BOTH"

SETTINGS = Settings()

BROKER: AbstractBroker = PaperBroker(starting_cash=SETTINGS.paper_capital)
OPEN_SYMBOLS: Dict[str, dict] = {}
QUOTES: Dict[str, float] = {}
CANDIDATES: List[dict] = []
LAST_EXIT_BAR: Dict[str, int] = {}

@app.get("/api/v1/settings")
def get_settings():
    s = SETTINGS.dict()
    s["api_key"] = "***" if s["api_key"] else ""
    s["access_token"] = "***" if s["access_token"] else ""
    s["broker"] = BROKER.name()
    s["wallet"] = BROKER.wallet_balance()
    s["market_open"] = is_market_open()
    return s

class SaveSettings(BaseModel):
    api_key: str = ""
    access_token: str = ""
    paper_capital: float = 100000.0
    max_positions: int = 5
    risk_per_trade: float = 0.02
    prefer_options: bool = True
    use_bo_co: bool = True
    only_index_options: bool = True
    only_weekly: bool = False
    option_kind: str = "BOTH"

@app.post("/api/v1/save_settings")
def save_settings(body: SaveSettings):
    global BROKER, SETTINGS
    SETTINGS.api_key = body.api_key or ""
    SETTINGS.access_token = body.access_token or ""
    SETTINGS.paper_capital = float(body.paper_capital or 100000.0)
    SETTINGS.max_positions = int(body.max_positions or 5)
    SETTINGS.risk_per_trade = float(body.risk_per_trade or 0.02)
    SETTINGS.prefer_options = bool(body.prefer_options)
    SETTINGS.use_bo_co = bool(body.use_bo_co)
    SETTINGS.only_index_options = bool(body.only_index_options)
    SETTINGS.only_weekly = bool(body.only_weekly)
    SETTINGS.option_kind = body.option_kind if body.option_kind in ("CE","PE","BOTH") else "BOTH"

    if is_market_open() and SETTINGS.api_key and SETTINGS.access_token:
        try:
            BROKER = ZerodhaKiteBroker(SETTINGS.api_key, SETTINGS.access_token)
            BROKER.refresh()
        except Exception as e:
            log.warning("Falling back to paper broker: %s", e)
            BROKER = PaperBroker(starting_cash=SETTINGS.paper_capital)
    else:
        BROKER = PaperBroker(starting_cash=SETTINGS.paper_capital)
    return {"ok": True, "broker": BROKER.name(), "wallet": BROKER.wallet_balance(), "market_open": is_market_open()}

class AutoToggle(BaseModel):
    enable: bool

@app.post("/api/v1/auto_toggle")
def auto_toggle(body: AutoToggle):
    SETTINGS.auto_enabled = bool(body.enable)
    return {"ok": True, "auto_enabled": SETTINGS.auto_enabled}

@app.get("/api/v1/portfolio")
def portfolio():
    if hasattr(BROKER, "positions"):
        pos = [vars(p) for p in getattr(BROKER, "positions").values()]
    else:
        pos = []
    return {"positions": pos, "cash": BROKER.wallet_balance()}

@app.get("/api/v1/candidates")
def candidates():
    return {"candidates": CANDIDATES}

@app.websocket("/ws/live")
async def live(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            payload = {
                "t": now_ist().isoformat(),
                "market_open": is_market_open(),
                "settings": {
                    "auto_enabled": SETTINGS.auto_enabled,
                    "broker": BROKER.name(),
                    "max_positions": SETTINGS.max_positions,
                    "risk_per_trade": SETTINGS.risk_per_trade,
                    "filters": {
                        "only_index_options": SETTINGS.only_index_options,
                        "only_weekly": SETTINGS.only_weekly,
                        "option_kind": SETTINGS.option_kind,
                    }
                },
                "wallet": BROKER.wallet_balance(),
                "open_symbols": OPEN_SYMBOLS,
                "quotes": QUOTES,
            }
            await ws.send_text(json.dumps(payload, default=str))
            await asyncio.sleep(2.0)
    except WebSocketDisconnect:
        return

async def auto_loop():
    global QUOTES, CANDIDATES, LAST_EXIT_BAR
    while True:
        try:
            BROKER.refresh()
            wallet = BROKER.wallet_balance()

            # Refresh candidates
            from scanner import top10_buy_candidates
            cands = top10_buy_candidates(
                getattr(BROKER, "kite", None) if hasattr(BROKER, "kite") else None,
                wallet_cash=wallet,
                prefer_options=SETTINGS.prefer_options,
                index_only=SETTINGS.only_index_options,
                weekly_only=SETTINGS.only_weekly,
                option_kind=SETTINGS.option_kind,
            )
            CANDIDATES = [{
                "symbol": s, "ltp": float(ltp), "affordable": bool(meta.get("affordable", False)),
                "score": round(float(meta.get("score", 0.0)), 3),
                "oi_chg": round(float(meta.get("oi_chg", 0.0)), 4),
                "iv_chg": round(float(meta.get("iv_chg", 0.0)), 4),
                "long_buildup": bool(meta.get("long_buildup", False)),
                "lot_size": int(meta.get("lot_size", 1))
            } for (s, ltp, meta) in cands]

            if SETTINGS.auto_enabled and is_market_open():
                open_count = len(OPEN_SYMBOLS)
                slots = max(SETTINGS.max_positions - open_count, 0)
                bar_now = current_minute_bar()

                for row in CANDIDATES:
                    if slots <= 0:
                        break
                    s, ltp, affordable, lot = row["symbol"], row["ltp"], row["affordable"], int(row["lot_size"] or 1)
                    if s in OPEN_SYMBOLS:
                        continue
                    last_exit = LAST_EXIT_BAR.get(s, None)
                    if last_exit is not None and last_exit == bar_now:
                        continue
                    if not affordable:
                        continue

                    qty = qty_for_wallet(ltp, lot, wallet_cash=wallet, risk_perc=SETTINGS.risk_per_trade, sl_pct=0.30)
                    if qty < lot:
                        continue

                    sl, tp = (round(ltp * (1 - 0.30), 2), round(ltp * (1 + 0.25), 2))
                    order = BROKER.place_market_order(s, "BUY", qty=qty, price_hint=ltp, sl=sl, tp=tp, use_bo_co=SETTINGS.use_bo_co)
                    if order.status == "FILLED":
                        OPEN_SYMBOLS[s] = {"entry": float(order.filled_price or ltp), "sl": sl, "tp": tp, "qty": order.qty, "lot_size": lot}
                        slots -= 1

            # Quotes for open symbols
            if hasattr(BROKER, "kite") and getattr(BROKER, "kite") is not None and OPEN_SYMBOLS:
                try:
                    k = BROKER.kite
                    q = k.quote([f"NFO:{s}" for s in OPEN_SYMBOLS.keys()])
                    QUOTES = {sym: float(data.get("last_price") or data.get("last_traded_price") or 0.0)
                              for exsym, data in q.items() for sym in [exsym.split(":")[-1]]}
                except Exception as e:
                    log.warning("quote failed: %s", e)
            else:
                # simulate drift
                from random import random
                for s, data in list(OPEN_SYMBOLS.items()):
                    last = data.get("last", data["entry"])
                    drift = last * 0.002
                    newp = max(0.01, last + drift if random() > 0.5 else last - drift)
                    QUOTES[s] = newp
                    OPEN_SYMBOLS[s]["last"] = newp

            # Exits
            bar_now = current_minute_bar()
            for s, data in list(OPEN_SYMBOLS.items()):
                last = QUOTES.get(s, data["entry"])
                if last <= data["sl"] or last >= data["tp"]:
                    if hasattr(BROKER, "positions") and s in getattr(BROKER, "positions", {}):
                        # close position in paper mode book if present
                        from broker import Position
                        BROKER.close_position(BROKER.positions[s], last)
                    del OPEN_SYMBOLS[s]
                    LAST_EXIT_BAR[s] = bar_now

            await asyncio.sleep(5.0)
        except Exception as e:
            log.error("auto_loop error: %s", e)
            await asyncio.sleep(3.0)

@app.on_event("startup")
async def on_start():
    asyncio.create_task(auto_loop())
