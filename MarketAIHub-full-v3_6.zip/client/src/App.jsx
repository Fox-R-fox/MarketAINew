
import React from 'react'
import LiveDataFeed from './components/LiveDataFeed'
import SettingsPanel from './components/SettingsPanel'
import CandidatesTable from './components/CandidatesTable'
import PositionsTable from './components/PositionsTable'
import EventFeed from './components/EventFeed'

export default function App(){
  return (
    <div className="container">
      <div className="card">
        <div className="row" style={{justifyContent:'space-between'}}>
          <div>
            <h1>MarketAIHub</h1>
            <div className="muted">F&O auto-trader: OI/IV momentum, long build-up, lot-aware sizing, filters, CO/BO fallback.</div>
          </div>
          <ThemeToggle />
        </div>
      </div>
      <div className="card">
        <SettingsPanel />
      </div>
      <LiveDataFeed>
        {({ live, portfolio, candidates }) => (
          <>
            <div className="card">
              <h3>Status</h3>
              <div className="row">
                <span className="badge">Execution: {live?.settings?.broker || '-'}</span>
                <span className="badge">Data: {live?.zerodha_connected ? 'Zerodha ✓' : 'No data'}</span>
                <span className="badge">{live?.market_open ? 'MARKET OPEN' : 'MARKET CLOSED'}</span>
                {!live?.market_open && live?.simulate_closed_market ? <span className="badge">Simulating market</span> : null}
              </div>
              <div className="muted">{live?.settings?.broker === 'paper' && live?.zerodha_connected ? 'Connected to Zerodha for data; executing on Paper because market is closed.' : ''}</div>
              <div>Wallet: ₹{(live?.wallet || 0).toFixed(2)}</div>
              <div>Auto: {live?.settings?.auto_enabled ? 'ON' : 'OFF'}</div>
              <div>Now: {live?.t || '-'}</div>
            </div>
            <div className="card">
              <h3>Top Candidates</h3>
              <CandidatesTable rows={candidates?.candidates || []} />
              {candidates?.candidates?.length > 0 && (
                <div className="muted">Top pick: <strong>{candidates.candidates[0].symbol}</strong> LTP {candidates.candidates[0].ltp.toFixed(2)} | Score {candidates.candidates[0].score.toFixed(3)} | Affordable: {candidates.candidates[0].affordable ? 'Yes' : 'No'}</div>
              )}
            </div>
            <div className="card">
              <h3>Open Positions</h3>
              <PositionsTable rows={portfolio?.positions || []} quotes={live?.quotes || {}} />
            </div>
            <div className="card">
              <h3>Performance (Cumulative P&L)</h3>
              <ProfitChart perf={live?.perf || []} events={live?.events || []} />
              <div className="muted">Cum P&L: ₹{(live?.cum_pnl||0).toFixed(2)}</div>
            </div>
            <div className="card">
              <h3>Activity</h3>
              <EventFeed events={live?.events || []} />
            </div>
          </>
        )}
      </LiveDataFeed>
    </div>
  )
}
