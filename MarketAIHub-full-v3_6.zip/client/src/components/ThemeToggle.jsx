
import React, { useEffect, useState } from 'react'

export default function ThemeToggle(){
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light')

  useEffect(()=>{
    document.documentElement.setAttribute('data-theme', theme)
    localStorage.setItem('theme', theme)
  }, [theme])

  const next = () => setTheme(t => t === 'light' ? 'dark' : 'light')

  return (
    <button onClick={next} className="badge" title="Toggle theme">
      Theme: {theme === 'light' ? '🌤️ Light' : '🌙 Dark'}
    </button>
  )
}
