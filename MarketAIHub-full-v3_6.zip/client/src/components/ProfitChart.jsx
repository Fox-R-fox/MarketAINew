
import React, { useMemo } from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts'

export default function ProfitChart({ perf = [], events = [] }){
  // Fallback: if no perf series from server, build cumulative pnl from exit events
  const data = useMemo(()=>{
    if(perf && perf.length > 0){
      return perf.map(p => ({ t: p.t, pnl: p.pnl }))
    }
    let cum = 0
    const rows = []
    for(const e of events || []){
      if(e.type === 'exit' && typeof e.pnl === 'number'){
        cum += e.pnl
        rows.push({ t: e.t, pnl: cum })
      }
    }
    return rows
  }, [perf, events])

  if(!data || data.length === 0){
    return <div className="muted">No realized P&L yet.</div>
  }

  return (
    <div style={{ width:'100%', height: 260 }}>
      <ResponsiveContainer>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="t" hide />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="pnl" stroke="#0ea5e9" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
