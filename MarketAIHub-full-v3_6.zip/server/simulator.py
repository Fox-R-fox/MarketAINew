
from __future__ import annotations
import math, random, time
from dataclasses import dataclass

@dataclass
class SimState:
    last: float
    sigma: float      # per-tick volatility (std dev as fraction of price)
    dt: float = 1.0   # tick time step (seconds)

def gbm_tick(state: SimState) -> float:
    # Geometric Brownian Motion step: S(t+dt) = S(t) * exp((mu - 0.5*sigma^2)*dt + sigma*sqrt(dt)*Z)
    # We use mu ~ 0 for neutrality; per-tick sigma derived from ATR / 1m candles.
    z = random.gauss(0.0, 1.0)
    drift = -0.5 * (state.sigma ** 2) * state.dt
    shock = state.sigma * math.sqrt(state.dt) * z
    newp = max(0.01, state.last * math.exp(drift + shock))
    state.last = newp
    return newp
