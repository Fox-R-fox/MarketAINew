
# MarketAIHub (Full Stack)

FastAPI backend + React frontend for F&O auto-trading with Zerodha (or paper).

## Structure
```
MarketAIHub/
├─ server/          # FastAPI backend
└─ client/          # React frontend (Vite)
```

## Run backend
```
cd server
pip install -r requirements.txt
# optional for live Zerodha: pip install kiteconnect
uvicorn app:app --reload --port 8000
```

## Run frontend
```
cd client
npm install
npm run dev
# open http://localhost:5173
```

## Configure
Use the **Settings** panel in the UI to set API key/token, risk, filters, etc.
Automode will place **CO/regular MIS MARKET** orders when the market is open and credentials are valid; otherwise it paper trades.

To add exchange holidays, create `server/holidays.json` as an array of ISO dates:
```json
["2025-10-24", "2025-11-14"]
```
