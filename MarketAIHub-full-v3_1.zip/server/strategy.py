
from __future__ import annotations
from typing import Tuple

TP_PCT = 0.25
SL_PCT = 0.30

def calc_sl_tp(entry: float) -> Tuple[float, float]:
    sl = round(entry * (1.0 - SL_PCT), 2)
    tp = round(entry * (1.0 + TP_PCT), 2)
    return sl, tp

def should_exit(last_price: float, sl: float, tp: float) -> str:
    if last_price <= sl:
        return "SL"
    if last_price >= tp:
        return "TP"
    return ""
