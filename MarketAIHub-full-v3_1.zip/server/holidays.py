
from __future__ import annotations
import datetime as dt
from typing import Set, Optional
import json, os

_EXTRA: Set[str] = set()
_file = os.path.join(os.path.dirname(__file__), "holidays.json")
if os.path.exists(_file):
    try:
        with open(_file, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                _EXTRA = set(str(x) for x in data)
    except Exception:
        pass

def is_holiday(d: dt.date) -> bool:
    if d.weekday() >= 5:
        return True
    return d.isoformat() in _EXTRA
