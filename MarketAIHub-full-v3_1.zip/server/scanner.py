
from __future__ import annotations
import logging, datetime as dt
from typing import List, Dict, Tuple
from utils import now_ist

try:
    from kiteconnect import KiteConnect
except Exception:
    KiteConnect = None

log = logging.getLogger("scanner")

_INSTR_CACHE: List[dict] = []
_LOT_MAP: Dict[str, int] = {}

INDEX_NAMES = {"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "SENSEX", "BANKEX"}

def _load_instruments(kite) -> List[dict]:
    global _INSTR_CACHE, _LOT_MAP
    if kite is None:
        return []
    if _INSTR_CACHE:
        return _INSTR_CACHE
    try:
        rows = kite.instruments("NFO")
        _INSTR_CACHE = rows or []
        _LOT_MAP = {r["tradingsymbol"]: int(r.get("lot_size", 1)) for r in _INSTR_CACHE}
        return _INSTR_CACHE
    except Exception as e:
        log.warning("instruments fetch failed: %s", e)
        return []

def lot_size_for(symbol: str) -> int:
    return _LOT_MAP.get(symbol, 1)

def _is_index_row(r: dict) -> bool:
    nm = (r.get("name") or "").upper()
    return any(n in nm for n in INDEX_NAMES)

def _is_weekly(r: dict) -> bool:
    try:
        exp = r.get("expiry")
        if not exp:
            return False
        if isinstance(exp, str):
            exp_d = dt.datetime.fromisoformat(exp).date()
        else:
            exp_d = exp if isinstance(exp, dt.date) else None
        if not exp_d:
            return False
        today = now_ist().date()
        return (exp_d - today).days <= 7
    except Exception:
        return False

def universe_fno(kite) -> List[dict]:
    return _load_instruments(kite)

def _apply_filters(rows: List[dict], *, index_only: bool, weekly_only: bool, option_kind: str) -> List[dict]:
    out = []
    for r in rows:
        if r.get("instrument_type") != "OPT":
            continue
        if index_only and not _is_index_row(r):
            continue
        if weekly_only and not _is_weekly(r):
            continue
        if option_kind in ("CE", "PE"):
            if (r.get("option_type") or "").upper() != option_kind:
                continue
        out.append(r)
    return out

def _rank_options_with_oi_iv(kite, wallet_cash: float, limit: int = 10, *, index_only: bool, weekly_only: bool, option_kind: str) -> List[Tuple[str, float, dict]]:
    inst = universe_fno(kite)
    if not inst: return []
    opts = _apply_filters(inst, index_only=index_only, weekly_only=weekly_only, option_kind=option_kind)
    if not opts: return []

    sample = opts[:800]
    symbols = [f"NFO:{r['tradingsymbol']}" for r in sample]
    try:
        q = kite.quote(symbols)
    except Exception as e:
        log.warning("quote failed: %s", e)
        return []

    ranked: List[Tuple[str, float, dict]] = []
    for exsym, data in q.items():
        tsym = exsym.split(":")[-1]
        ltp = float(data.get("last_price") or data.get("last_traded_price") or 0.0)
        prev_close = float(data.get("ohlc", {}).get("close") or 0.0)
        change = (ltp - prev_close) / prev_close if ltp and prev_close else 0.0

        oi = float(data.get("oi") or 0.0)
        odh = float(data.get("oi_day_high") or 0.0)
        odl = float(data.get("oi_day_low") or 0.0)
        base = (odh + odl) / 2.0 if (odh and odl) else 0.0
        oi_chg = (oi - base) / base if base else 0.0

        iv = float(data.get("iv") or 0.0)
        ivh = float(data.get("iv_day_high") or 0.0)
        ivl = float(data.get("iv_day_low") or 0.0)
        base_iv = (ivh + ivl) / 2.0 if (ivh and ivl) else 0.0
        iv_chg = (iv - base_iv) / base_iv if base_iv else 0.0

        long_buildup = (change >= 0 and oi_chg > 0)

        iv_penalty = 0.1 if iv_chg > 0 else 0.0
        if iv_chg < -0.05: iv_penalty = -0.5
        if iv_chg > 0.15: iv_penalty = -0.3

        score = (1.0 if long_buildup else -0.2) + (change * 1.0) + (oi_chg * 0.8) + iv_penalty

        lot = lot_size_for(tsym)
        notional = ltp * lot
        affordable = (wallet_cash <= 0) or (notional <= wallet_cash * 0.5)

        ranked.append((tsym, ltp, {"score": score, "affordable": affordable, "oi_chg": oi_chg, "iv_chg": iv_chg, "long_buildup": long_buildup, "lot_size": lot}))
    ranked.sort(key=lambda x: x[2]["score"], reverse=True)
    return ranked[:limit]

def top10_buy_candidates(kite, wallet_cash: float, prefer_options: bool = True, *, index_only: bool = True, weekly_only: bool = False, option_kind: str = "BOTH") -> List[Tuple[str, float, dict]]:
    if prefer_options and kite is not None:
        ranked = _rank_options_with_oi_iv(kite, wallet_cash, 10, index_only=index_only, weekly_only=weekly_only, option_kind=option_kind if option_kind in ("CE","PE") else "BOTH")
        if ranked:
            return ranked

    inst = universe_fno(kite)
    futs = [r for r in inst if r.get("instrument_type") == "FUT"]
    futs.sort(key=lambda r: (r.get("lot_size", 1), r.get("segment") == "NFO-FUT"), reverse=True)
    symbols = [r["tradingsymbol"] for r in futs[:200]]
    symbol_to_ltp = {}
    if kite is not None and symbols:
        try:
            q = kite.quote([f"NFO:{s}" for s in symbols])
            for key, data in q.items():
                tsym = key.split(":")[-1]
                ltp = data.get("last_price") or data.get("last_traded_price") or 0.0
                symbol_to_ltp[tsym] = float(ltp)
        except Exception as e:
            log.warning("quote failed: %s", e)
    picks = []
    for r in futs:
        tsym = r["tradingsymbol"]
        lot = int(r.get("lot_size", 1))
        ltp = float(symbol_to_ltp.get(tsym, r.get("tick_size", 1.0) * 100.0))
        notional = ltp * lot
        affordable = (wallet_cash <= 0) or (notional <= wallet_cash * 0.5)
        if affordable:
            picks.append((tsym, ltp, {"score": 0.0, "affordable": True, "fallback": True, "lot_size": lot}))
        if len(picks) >= 10:
            break
    return picks

def qty_for_wallet(ltp: float, lot_size: int, wallet_cash: float, risk_perc: float = 0.02, sl_pct: float = 0.30) -> int:
    if ltp <= 0 or lot_size <= 0 or wallet_cash <= 0:
        return 0
    max_value = (wallet_cash * risk_perc) / sl_pct
    lots = max(int(max_value // (ltp * lot_size)), 0)
    return max(lots * lot_size, 0)
