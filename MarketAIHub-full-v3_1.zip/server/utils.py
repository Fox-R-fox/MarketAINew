
import datetime as dt
from typing import Optional
import pytz
from holidays import is_holiday

IST = pytz.timezone("Asia/Kolkata")

def now_ist() -> dt.datetime:
    return dt.datetime.now(IST)

def is_market_open(now: Optional[dt.datetime] = None) -> bool:
    n = now or now_ist()
    if is_holiday(n.date()):
        return False
    start = n.replace(hour=9, minute=15, second=0, microsecond=0)
    end = n.replace(hour=15, minute=30, second=0, microsecond=0)
    return start <= n <= end

def current_minute_bar(ts: Optional[dt.datetime] = None) -> int:
    t = ts or now_ist()
    return int(t.timestamp() // 60)
