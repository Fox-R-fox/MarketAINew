
from __future__ import annotations
import logging
from dataclasses import dataclass, field
from typing import Dict, Optional, Literal
from utils import now_ist

logger = logging.getLogger("broker")

Side = Literal["BUY", "SELL"]

@dataclass
class Order:
    id: str
    symbol: str
    qty: int
    side: Side
    price: float
    status: Literal["OPEN", "FILLED", "REJECTED", "CANCELLED"] = "OPEN"
    filled_price: Optional[float] = None
    ts: float = field(default_factory=lambda: now_ist().timestamp())

@dataclass
class Position:
    symbol: str
    qty: int
    avg_price: float
    side: Side
    sl: float
    tp: float
    open_order_id: str
    open_time: float
    status: Literal["OPEN", "CLOSED"] = "OPEN"
    close_price: Optional[float] = None
    close_time: Optional[float] = None
    pnl: float = 0.0
    lot_size: int = 1

class AbstractBroker:
    def name(self) -> str: ...
    def wallet_balance(self) -> float: ...
    def refresh(self) -> None: ...
    def place_market_order(self, symbol: str, side: Side, qty: int, price_hint: Optional[float]=None, sl: Optional[float]=None, tp: Optional[float]=None, use_bo_co: bool=False) -> Order: ...
    def close_position(self, pos: Position, exit_price: float) -> None: ...

class PaperBroker(AbstractBroker):
    def __init__(self, starting_cash: float = 100000.0):
        self.cash = float(starting_cash)
        self.orders: Dict[str, Order] = {}
        self.positions: Dict[str, Position] = {}
    def name(self) -> str: return "paper"
    def wallet_balance(self) -> float: return self.cash
    def refresh(self) -> None: pass

    def _gen_id(self) -> str:
        import uuid; return f"PAPER-{uuid.uuid4().hex[:10]}"

    def place_market_order(self, symbol: str, side: Side, qty: int, price_hint: Optional[float]=None, sl: Optional[float]=None, tp: Optional[float]=None, use_bo_co: bool=False) -> Order:
        price = float(price_hint or 0.0)
        cost = price * qty
        if side == "BUY" and self.cash < cost:
            return Order(id=self._gen_id(), symbol=symbol, qty=qty, side=side, price=price, status="REJECTED")
        oid = self._gen_id()
        order = Order(id=oid, symbol=symbol, qty=qty, side=side, price=price, status="FILLED", filled_price=price)
        self.orders[oid] = order
        if side == "BUY":
            self.cash -= cost
        else:
            self.cash += cost
        # Create/open position
        self.positions[symbol] = Position(symbol=symbol, qty=qty, avg_price=price, side=side, sl=sl or 0.0, tp=tp or 0.0, open_order_id=oid, open_time=order.ts)
        return order

    def close_position(self, pos: Position, exit_price: float) -> None:
        if pos.status != "OPEN": return
        if pos.side == "BUY":
            self.cash += pos.qty * exit_price
            pnl = (exit_price - pos.avg_price) * pos.qty
        else:
            self.cash -= pos.qty * exit_price
            pnl = (pos.avg_price - exit_price) * pos.qty
        pos.pnl = pnl
        pos.close_price = exit_price
        pos.close_time = now_ist().timestamp()
        pos.status = "CLOSED"

try:
    from kiteconnect import KiteConnect
except Exception:
    KiteConnect = None

class ZerodhaKiteBroker(AbstractBroker):
    def __init__(self, api_key: str, access_token: str):
        if KiteConnect is None:
            raise RuntimeError("kiteconnect not installed")
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self._cached_balance = 0.0

    def name(self) -> str: return "zerodha"

    def refresh(self) -> None:
        try:
            mf = self.kite.margins("equity")
            self._cached_balance = float(mf.get("available", {}).get("live_balance", 0.0))
        except Exception as e:
            logger.warning("Failed to refresh Zerodha margins: %s", e)

    def wallet_balance(self) -> float:
        return self._cached_balance

    def place_market_order(self, symbol: str, side: Side, qty: int, price_hint: Optional[float]=None, sl: Optional[float]=None, tp: Optional[float]=None, use_bo_co: bool=False) -> Order:
        try:
            ttype = "BUY" if side=="BUY" else "SELL"
            exchange = "NFO"
            tradingsymbol = symbol.split(":")[-1]
            if use_bo_co and sl is not None:
                try:
                    order_id = self.kite.place_order(
                        variety="co",
                        exchange=exchange, tradingsymbol=tradingsymbol, transaction_type=ttype,
                        quantity=qty, product="MIS", order_type="MARKET",
                        trigger_price=sl
                    )
                    return Order(id=order_id, symbol=tradingsymbol, qty=qty, side=side, price=float(price_hint or 0.0), status="FILLED", filled_price=price_hint)
                except Exception as e:
                    logger.warning("CO failed: %s; falling back to MARKET MIS", e)
            order_id = self.kite.place_order(
                variety="regular",
                exchange=exchange, tradingsymbol=tradingsymbol, transaction_type=ttype,
                quantity=qty, product="MIS", order_type="MARKET"
            )
            return Order(id=order_id, symbol=tradingsymbol, qty=qty, side=side, price=float(price_hint or 0.0), status="FILLED", filled_price=price_hint)
        except Exception as e:
            logger.error("Zerodha order failed for %s: %s", symbol, e)
            return Order(id="REJECTED", symbol=symbol, qty=qty, side=side, price=float(price_hint or 0.0), status="REJECTED")
