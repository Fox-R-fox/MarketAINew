
import React, { useEffect, useState } from 'react'

export default function SettingsPanel(){
  const [s, setS] = useState(null)
  const [form, setForm] = useState({
    api_key: '',
    access_token: '',
    paper_capital: 100000,
    max_positions: 5,
    risk_per_trade: 0.02,
    prefer_options: true,
    use_bo_co: true,
    only_index_options: true,
    only_weekly: false,
    option_kind: 'BOTH'
  })

  useEffect(()=>{
    fetch('/api/v1/settings').then(r=>r.json()).then((j)=>{
      setS(j)
      setForm(f=>({ ...f,
        paper_capital:  j.paper_capital ?? f.paper_capital,
        max_positions:  j.max_positions ?? f.max_positions,
        risk_per_trade: j.risk_per_trade ?? f.risk_per_trade,
        prefer_options: j.prefer_options ?? f.prefer_options,
        use_bo_co: j.use_bo_co ?? f.use_bo_co,
        only_index_options: j.only_index_options ?? f.only_index_options,
        only_weekly: j.only_weekly ?? f.only_weekly,
        option_kind: j.option_kind ?? f.option_kind,
      }))
    })
  }, [])

  const save = async ()=>{
    const r = await fetch('/api/v1/save_settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    })
    const j = await r.json()
    setS(prev=>({...prev, ...j}))
  }

  const toggle = async ()=>{
    const enable = !(s?.auto_enabled)
    const r = await fetch('/api/v1/auto_toggle', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ enable })
    })
    const j = await r.json()
    setS(prev=>({...prev, auto_enabled: j.auto_enabled }))
  }

  const setValue = (k, v)=> setForm(prev=>({...prev, [k]: v}))

  return (
    <div className="grid3">
      <div>
        <h3>Broker</h3>
        <div className="row"><input placeholder="Zerodha API Key" onChange={e=>setValue('api_key', e.target.value)} /></div>
        <div className="row"><input placeholder="Zerodha Access Token" onChange={e=>setValue('access_token', e.target.value)} /></div>
        <div className="row"><input type="number" defaultValue={form.paper_capital} onChange={e=>setValue('paper_capital', parseFloat(e.target.value||'0'))} /></div>
        <div className="row">
          <label><input type="checkbox" defaultChecked={form.prefer_options} onChange={e=>setValue('prefer_options', e.target.checked)} /> Prefer Options</label>
          <label><input type="checkbox" defaultChecked={form.use_bo_co} onChange={e=>setValue('use_bo_co', e.target.checked)} /> Try CO/BO</label>
        </div>
        <button className="primary" onClick={save}>Save</button>
      </div>

      <div>
        <h3>Risk & Limits</h3>
        <div className="row">Max Positions: <input type="range" min="1" max="20" defaultValue={form.max_positions} onChange={e=>setValue('max_positions', parseInt(e.target.value))} /></div>
        <div className="row">Risk / Trade: <input type="range" min="1" max="10" defaultValue={form.risk_per_trade*100} onChange={e=>setValue('risk_per_trade', parseInt(e.target.value)/100)} /> {Math.round(form.risk_per_trade*100)}%</div>
        <button onClick={toggle}>{s?.auto_enabled ? 'Stop Auto' : 'Start Auto'}</button>
      </div>

      <div>
        <h3>Filters</h3>
        <div className="row">
          <label><input type="checkbox" defaultChecked={form.only_index_options} onChange={e=>setValue('only_index_options', e.target.checked)} /> Index options only</label>
          <label><input type="checkbox" defaultChecked={form.only_weekly} onChange={e=>setValue('only_weekly', e.target.checked)} /> Weekly expiries only</label>
        </div>
        <div className="row">
          <select defaultValue={form.option_kind} onChange={e=>setValue('option_kind', e.target.value)}>
            <option value="BOTH">Both</option>
            <option value="CE">Calls (CE)</option>
            <option value="PE">Puts (PE)</option>
          </select>
        </div>
      </div>
    </div>
  )
}
