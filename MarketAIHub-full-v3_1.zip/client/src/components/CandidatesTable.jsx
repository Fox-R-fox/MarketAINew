
import React from 'react'

export default function CandidatesTable({ rows }){
  return (
    <table>
      <thead>
        <tr><th>Symbol</th><th>Lot</th><th>LTP</th><th>Score</th><th>OI Δ</th><th>IV Δ</th><th>Long Buildup</th><th>Affordable</th></tr>
      </thead>
      <tbody>
        {rows.length === 0 && (<tr><td colSpan='8'>No candidates yet. Check filters or market status.</td></tr>)}
        {rows.map((c)=> (
          <tr key={c.symbol} style={{background: 'rgba(34,211,238,0.08)'}}>
            <td>{c.symbol}</td>
            <td>{c.lot_size}</td>
            <td>{c.ltp.toFixed(2)}</td>
            <td>{c.score.toFixed(3)}</td>
            <td>{(c.oi_chg*100).toFixed(2)}%</td>
            <td>{(c.iv_chg*100).toFixed(2)}%</td>
            <td>{c.long_buildup ? '✅' : '—'}</td>
            <td>{c.affordable ? '✅' : '—'}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
