
import React from 'react'

export default function EventFeed({ events }){
  if(!events || events.length === 0){
    return <div className="muted">No events yet.</div>
  }
  return (
    <div style={{maxHeight: 220, overflowY: 'auto'}}>
      <table>
        <thead><tr><th>Time</th><th>Type</th><th>Message</th></tr></thead>
        <tbody>
          {events.slice().reverse().map((e, idx)=> (
            <tr key={idx}>
              <td>{e.t}</td><td>{e.type}</td><td>{e.msg}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
