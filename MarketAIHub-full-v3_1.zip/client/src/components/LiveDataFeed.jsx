
import React, { useEffect, useRef, useState } from 'react'

function makeWsUrl(path = '/ws/live'){
  const proto = (window.location.protocol === 'https:') ? 'wss' : 'ws'
  // Use relative host so Vite proxy handles it during dev
  const host = window.location.host
  return `${proto}://${host}${path}`
}

export default function LiveDataFeed({ children }){
  const [live, setLive] = useState(null)
  const [portfolio, setPortfolio] = useState(null)
  const [candidates, setCandidates] = useState(null)
  const [status, setStatus] = useState('connecting')
  const wsRef = useRef(null)
  const retryRef = useRef(0)

  useEffect(()=>{
    function connect(){
      setStatus('connecting')
      const ws = new WebSocket(makeWsUrl())
      wsRef.value = ws
      ws.onopen = ()=>{
        retryRef.current = 0
        setStatus('connected')
      }
      ws.onmessage = (ev)=>{
        try{
          const d = JSON.parse(ev.data)
          setLive(d)
          // Fetch REST data
          fetch('/api/v1/portfolio').then(r=>r.json()).then(setPortfolio).catch(()=>{})
          fetch('/api/v1/candidates').then(r=>r.json()).then(setCandidates).catch(()=>{})
        }catch(e){ console.error('WS parse error', e) }
      }
      ws.onerror = (e)=>{
        console.warn('WS error', e)
        setStatus('error')
      }
      ws.onclose = ()=>{
        setStatus('reconnecting')
        const backoff = Math.min(10000, 1000 * Math.pow(2, retryRef.current++))
        setTimeout(connect, backoff)
      }
    }
    connect()
    return ()=> { try { wsRef.value && wsRef.value.close() } catch(e){} }
  }, [])

  if(status !== 'connected' && !live){
    return <div className="card">Live feed status: <strong>{status}</strong>. If this persists, ensure the backend is running on port 8000.</div>
  }

  return children({ live, portfolio, candidates, status })
}
