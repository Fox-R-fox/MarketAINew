
import React from 'react'

export default function PositionsTable({ rows, quotes }){
  return (
    <table>
      <thead>
        <tr><th>Symbol</th><th>Qty</th><th>Lot</th><th>Entry</th><th>SL</th><th>TP</th><th>Last</th><th>PNL</th><th>Status</th></tr>
      </thead>
      <tbody>
        {(rows||[]).map((p)=>{
          const last = quotes?.[p.symbol] || p.avg_price
          const pnl = ((p.side === 'BUY') ? (last - p.avg_price) : (p.avg_price - last)) * p.qty
          return (
            <tr key={p.symbol}>
              <td>{p.symbol}</td>
              <td>{p.qty}</td>
              <td>{p.lot_size || '-'}</td>
              <td>{p.avg_price.toFixed(2)}</td>
              <td>{p.sl}</td>
              <td>{p.tp}</td>
              <td>{last.toFixed(2)}</td>
              <td>{pnl.toFixed(2)}</td>
              <td>{p.status}</td>
            </tr>
          )
        })}
      </tbody>
    </table>
  )
}
