import json
import os
from datetime import date

HOLIDAYS_FILE = 'holidays.json'
_holidays = set()

def _load_holidays():
    """Loads holiday dates from the JSON file into a set for quick lookups."""
    global _holidays
    if not os.path.exists(HOLIDAYS_FILE):
        return
        
    with open(HOLIDAYS_FILE, 'r') as f:
        holiday_dates = json.load(f)
        for d_str in holiday_dates:
            try:
                _holidays.add(date.fromisoformat(d_str))
            except (ValueError, TypeError):
                continue

_load_holidays()

def is_holiday(check_date: date):
    """Checks if the given date is a market holiday."""
    return check_date in _holidays
