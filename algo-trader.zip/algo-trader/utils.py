import datetime as dt
from pytz import timezone
import holidays as market_holidays

# Define Indian Standard Time and NSE market hours
IST = timezone('Asia/Kolkata')
MARKET_START = dt.time(9, 15)
MARKET_END = dt.time(15, 30)

def now_ist():
    """Returns the current time in IST."""
    return dt.datetime.now(IST)

def is_market_open():
    """
    Checks if the NSE market is currently open.
    Considers weekends, market hours, and public holidays.
    """
    now = now_ist()
    
    # Check if it's a weekend (Monday is 0, Sunday is 6)
    if now.weekday() >= 5:
        return False
        
    # Check if it's a declared market holiday
    if market_holidays.is_holiday(now.date()):
        return False
        
    # Check if current time is within market hours
    return MARKET_START <= now.time() <= MARKET_END

def current_minute_bar():
    """Returns the timestamp for the current minute bar."""
    now = now_ist()
    return now.replace(second=0, microsecond=0)
