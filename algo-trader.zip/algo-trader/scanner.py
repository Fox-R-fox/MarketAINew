import logging
import pandas as pd
from kiteconnect import KiteConnect
import joblib  # For loading the ML model
import os

# --- ML Model Integration ---
MODEL_FILE = 'model.pkl'

def get_ml_score(features):
    """
    Predicts a score using a pre-trained model.
    This is a placeholder for a real AI/ML model.
    """
    if not hasattr(get_ml_score, "model"):
        if os.path.exists(MODEL_FILE):
            try:
                get_ml_score.model = joblib.load(MODEL_FILE)
                logging.info(f"ML model '{MODEL_FILE}' loaded successfully.")
            except Exception as e:
                logging.error(f"Failed to load ML model: {e}")
                get_ml_score.model = None
        else:
            logging.warning(f"ML model file '{MODEL_FILE}' not found. Using default scoring.")
            get_ml_score.model = None

    if get_ml_score.model is None:
        return 0.5  # Return a neutral score if model is not available

    try:
        # Create a DataFrame with the correct feature names
        feature_df = pd.DataFrame([features])
        # The model expects features like: ['oi_chg_perc', 'iv_chg_perc', 'volume_chg_perc']
        # Ensure the input `features` dict matches what the model was trained on.
        score = get_ml_score.model.predict(feature_df)
        return score[0]
    except Exception as e:
        logging.error(f"Error during ML prediction: {e}")
        return 0.5


# --- Candidate Data Structure ---
class Candidate:
    def __init__(self, symbol, ltp, meta):
        self.symbol = symbol
        self.ltp = ltp
        self.meta = meta

    def to_dict(self):
        return {"symbol": self.symbol, "ltp": self.ltp, "meta": self.meta}

# --- Helper Functions ---
_kite_instance = None
def _get_kite_instance(api_key, api_secret):
    """Creates and caches a KiteConnect instance."""
    global _kite_instance
    if _kite_instance is None:
        # This part is simplified. A real app needs a full login flow.
        _kite_instance = KiteConnect(api_key=api_key)
        logging.info("KiteConnect instance created for scanning.")
    return _kite_instance

def _load_instruments(kite, exchange="NFO"):
    """Loads and caches F&O instrument list from Zerodha."""
    try:
        instruments = kite.instruments(exchange)
        df = pd.DataFrame(instruments)
        # Filter for NIFTY and BANKNIFTY options, and futures
        df = df[df['name'].isin(['NIFTY', 'BANKNIFTY'])]
        df['expiry'] = pd.to_datetime(df['expiry']).dt.date
        return df
    except Exception as e:
        logging.error(f"Failed to load instruments: {e}")
        return pd.DataFrame()

def _apply_filters(df, max_days_to_expiry=10):
    """Filters instruments for relevant, near-expiry options."""
    today = pd.to_datetime('today').date()
    df = df[df['expiry'] > today]
    df = df[(df['expiry'] - today).dt.days <= max_days_to_expiry]
    df = df[df['instrument_type'].isin(['CE', 'PE'])]
    # Filter for reasonable strike prices (e.g., within 10% of a typical spot price)
    # This is a heuristic to reduce the number of quotes needed.
    # A better approach uses the actual spot price.
    df = df[df['strike'].between(18000, 25000) | df['strike'].between(40000, 55000)]
    return df

# --- Main Scanner Logic ---
def top10_buy_candidates(api_key, api_secret, wallet_balance):
    """
    Scans the F&O segment and returns the top 10 ranked candidates for buying.
    """
    kite = _get_kite_instance(api_key, api_secret)
    
    # 1. Load and filter instruments
    instrument_df = _load_instruments(kite)
    if instrument_df.empty:
        return []
    
    filtered_df = _apply_filters(instrument_df)
    symbols = filtered_df['tradingsymbol'].tolist()
    logging.info(f"Scanning {len(symbols)} filtered instruments...")

    # 2. Fetch quotes in batches
    quotes = {}
    batch_size = 400
    for i in range(0, len(symbols), batch_size):
        batch = symbols[i:i+batch_size]
        try:
            # Prepend exchange name for the API call
            batch_with_exchange = [f"NFO:{s}" for s in batch]
            quote_batch = kite.quote(batch_with_exchange)
            quotes.update(quote_batch)
        except Exception as e:
            logging.warning(f"Could not fetch quotes for a batch: {e}")
            continue

    # 3. Rank candidates
    candidates = []
    for symbol in symbols:
        q_key = f"NFO:{symbol}"
        if q_key not in quotes or quotes[q_key]['last_price'] == 0:
            continue
        
        quote = quotes[q_key]
        depth = quote.get('depth', {})
        
        # --- Feature Engineering ---
        oi = quote.get('oi', 0)
        oi_day_high = quote.get('oi_day_high', 0)
        oi_day_low = quote.get('oi_day_low', 0)
        oi_chg = oi - (oi_day_high + oi_day_low) / 2 if oi_day_high > 0 else 0
        iv = quote.get('last_price', 0) * 0.15 # Heuristic IV, as it's not directly in quote
        
        # Check for long build-up (Price Increase + OI Increase)
        price_chg = quote.get('change', 0)
        long_buildup = price_chg > 0 and oi_chg > 0
        
        # --- Scoring ---
        # Base score on momentum and build-up
        score = 0
        if long_buildup: score += 1
        if oi_chg > 0: score += (oi_chg / oi) if oi > 0 else 0
        if price_chg > 0: score += (price_chg / quote['last_price']) if quote['last_price'] > 0 else 0
            
        # --- AI/ML Scoring ---
        ml_features = {
            'oi_chg_perc': (oi_chg / oi) * 100 if oi > 0 else 0,
            'iv_chg_perc': 0, # Placeholder
            'volume_chg_perc': ((quote['volume'] - quote['average_price']) / quote['average_price']) * 100 if quote['average_price'] > 0 else 0,
        }
        ml_score = get_ml_score(ml_features)
        
        # Combine base score with ML score (e.g., 70% base, 30% ML)
        final_score = (0.7 * score) + (0.3 * ml_score)

        if final_score > 0.5: # Minimum threshold
            lot_size = filtered_df.loc[filtered_df['tradingsymbol'] == symbol, 'lot_size'].iloc[0]
            affordable_qty = int((wallet_balance * 0.1) / quote['last_price'] // lot_size) * lot_size
            
            if affordable_qty > 0:
                candidates.append(Candidate(
                    symbol=symbol,
                    ltp=quote['last_price'],
                    meta={
                        'score': final_score,
                        'long_buildup': long_buildup,
                        'oi_chg': oi_chg,
                        'lot_size': int(lot_size),
                        'affordable_qty': int(affordable_qty)
                    }
                ))

    # 4. Sort and return top 10
    candidates.sort(key=lambda c: c.meta['score'], reverse=True)
    return candidates[:10]
