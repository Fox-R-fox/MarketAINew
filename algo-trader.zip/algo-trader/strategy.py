def calc_sl_tp(entry_price, sl_perc=0.30, tp_perc=0.25):
    """
    Calculates Stop-Loss and Take-Profit levels based on entry price.
    For options, these percentages are high due to volatility.
    
    Args:
        entry_price (float): The price at which the position was entered.
        sl_perc (float): The stop-loss percentage (e.g., 0.30 for 30%).
        tp_perc (float): The take-profit percentage (e.g., 0.25 for 25%).
        
    Returns:
        tuple: (stop_loss_price, take_profit_price)
    """
    if entry_price <= 0:
        return 0, 0
        
    stop_loss = entry_price * (1 - sl_perc)
    take_profit = entry_price * (1 + tp_perc)
    
    return stop_loss, take_profit

def should_exit(last_price, stop_loss, take_profit):
    """
    Determines if a position should be exited based on SL/TP levels.
    
    Args:
        last_price (float): The last traded price of the instrument.
        stop_loss (float): The calculated stop-loss price.
        take_profit (float): The calculated take-profit price.
        
    Returns:
        bool: True if the price hits SL or TP, False otherwise.
    """
    if last_price <= stop_loss:
        return True
    if last_price >= take_profit:
        return True
    return False
