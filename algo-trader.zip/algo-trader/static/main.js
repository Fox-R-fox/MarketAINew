document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const healthStatus = document.getElementById('health-status');
    const autoTradeBtn = document.getElementById('auto-trade-btn');
    const settingsForm = document.getElementById('settings-form');
    const settingsMessage = document.getElementById('settings-message');
    const apiKeyInput = document.getElementById('api-key');
    const apiSecretInput = document.getElementById('api-secret');
    const walletBalanceElem = document.getElementById('wallet-balance');
    const positionsTable = document.getElementById('positions-table');
    const candidatesTable = document.getElementById('candidates-table');
    const logsContainer = document.getElementById('logs-container');

    // --- WebSocket Connection ---
    function connectWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const ws = new WebSocket(`${protocol}//${window.location.host}/ws/live`);

        ws.onopen = () => {
            updateHealthStatus('green', 'Connected');
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            updateUI(data);
        };

        ws.onclose = () => {
            updateHealthStatus('red', 'Disconnected. Retrying...');
            setTimeout(connectWebSocket, 3000); // Retry connection after 3 seconds
        };

        ws.onerror = () => {
            updateHealthStatus('red', 'Connection Error');
            ws.close();
        };
    }

    // --- UI Update Functions ---
    function updateUI(data) {
        // Settings
        updateSettingsUI(data.settings);
        // Portfolio
        updatePortfolioUI(data.portfolio);
        // Candidates
        updateCandidatesUI(data.candidates);
        // Logs
        updateLogsUI(data.logs);
    }

    function updateHealthStatus(color, text) {
        const dot = healthStatus.querySelector('.status-dot');
        const textElem = healthStatus.querySelector('span:last-child');
        dot.className = `status-dot status-${color}`;
        textElem.textContent = text;
    }

    function updateSettingsUI(settings) {
        if (document.activeElement !== apiKeyInput) apiKeyInput.value = settings.api_key;
        if (document.activeElement !== apiSecretInput) apiSecretInput.value = settings.api_secret;

        if (settings.auto_trading_enabled) {
            autoTradeBtn.textContent = 'Disable Auto Trading';
            autoTradeBtn.className = 'w-full py-3 px-4 rounded-lg font-bold text-white transition-all duration-300 bg-red-600 hover:bg-red-700';
        } else {
            autoTradeBtn.textContent = 'Enable Auto Trading';
            autoTradeBtn.className = 'w-full py-3 px-4 rounded-lg font-bold text-white transition-all duration-300 bg-green-600 hover:bg-green-700';
        }
    }

    function updatePortfolioUI(portfolio) {
        walletBalanceElem.textContent = `₹ ${portfolio.wallet.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        
        if (portfolio.positions.length === 0) {
            positionsTable.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-gray-500">No open positions.</td></tr>';
            return;
        }

        let tableHtml = '';
        portfolio.positions.forEach(pos => {
            const pnlClass = pos.pnl >= 0 ? 'text-green-400' : 'text-red-400';
            tableHtml += `
                <tr class="border-b border-gray-700 hover:bg-gray-700/50">
                    <td class="px-4 py-2 font-medium">${pos.symbol}</td>
                    <td class="px-4 py-2">${pos.qty}</td>
                    <td class="px-4 py-2">${pos.entry_price.toFixed(2)}</td>
                    <td class="px-4 py-2">${pos.ltp.toFixed(2)}</td>
                    <td class="px-4 py-2 font-bold ${pnlClass}">${pos.pnl.toFixed(2)}</td>
                    <td class="px-4 py-2">${pos.sl.toFixed(2)} / ${pos.tp.toFixed(2)}</td>
                </tr>
            `;
        });
        positionsTable.innerHTML = tableHtml;
    }

    function updateCandidatesUI(candidates) {
        if (candidates.length === 0) {
            candidatesTable.innerHTML = '<tr><td colspan="4" class="text-center py-4 text-gray-500">No suitable candidates found.</td></tr>';
            return;
        }

        let tableHtml = '';
        candidates.forEach(c => {
            tableHtml += `
                 <tr class="border-b border-gray-700 hover:bg-gray-700/50">
                    <td class="px-4 py-2 font-medium">${c.symbol}</td>
                    <td class="px-4 py-2">${c.ltp.toFixed(2)}</td>
                    <td class="px-4 py-2 font-bold text-cyan-400">${c.meta.score.toFixed(3)}</td>
                    <td class="px-4 py-2 text-gray-400">Qty: ${c.meta.affordable_qty} | Lot: ${c.meta.lot_size}</td>
                </tr>
            `;
        });
        candidatesTable.innerHTML = tableHtml;
    }

    function updateLogsUI(logs) {
        logsContainer.innerHTML = logs.map(log => {
            let logClass = 'text-gray-400';
            if (log.includes('ERROR')) logClass = 'text-red-400';
            if (log.includes('SUCCESS') || log.includes('placed')) logClass = 'text-green-400';
            if (log.includes('WARNING')) logClass = 'text-yellow-400';
            return `<p class="${logClass}">${log}</p>`;
        }).join('');
    }


    // --- Event Listeners ---
    autoTradeBtn.addEventListener('click', () => {
        fetch('/api/auto_toggle', { method: 'POST' })
            .then(res => res.json())
            .catch(err => console.error('Error toggling auto trade:', err));
    });

    settingsForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(settingsForm);
        const data = Object.fromEntries(formData.entries());
        
        fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(result => {
            settingsMessage.textContent = result.message;
            setTimeout(() => settingsMessage.textContent = '', 3000);
        })
        .catch(err => console.error('Error saving settings:', err));
    });

    // --- Initial Kick-off ---
    connectWebSocket();
});
