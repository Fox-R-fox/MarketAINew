import json
import logging
import os
import threading
import time
from datetime import datetime

from flask import Flask, jsonify, render_template, request
from flask_sock import Sock

import broker
import scanner
import utils
from strategy import calc_sl_tp, should_exit

# --- Basic Setup ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)
sock = Sock(app)

# --- Global State ---
# These variables hold the application's state and are updated by the auto_loop.
app_state = {
    "settings": {"api_key": "", "api_secret": "", "auto_trading_enabled": False},
    "health": {"status": "starting", "last_update": None},
    "portfolio": {"wallet": 50000, "positions": []},  # Start with a default paper wallet
    "candidates": [],
    "logs": [],
    "broker_instance": None,
}

# Lock for thread-safe operations on app_state
state_lock = threading.Lock()

# --- Configuration ---
CONFIG_FILE = 'config.json'
ACTION_LOG_FILE = 'action_log.txt'

def load_settings():
    """Loads settings from the config file."""
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {"api_key": "", "api_secret": "", "auto_trading_enabled": False}

def save_settings(settings):
    """Saves settings to the config file."""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(settings, f, indent=4)

def log_action(message):
    """Logs an action to both the UI and a file."""
    timestamp = utils.now_ist().strftime('%Y-%m-%d %H:%M:%S')
    log_entry = f"[{timestamp}] {message}"
    logging.info(message)
    with state_lock:
        app_state["logs"].insert(0, log_entry)
        # Keep logs to a reasonable size in memory
        if len(app_state["logs"]) > 100:
            app_state["logs"].pop()
    with open(ACTION_LOG_FILE, 'a') as f:
        f.write(log_entry + '\n')

# --- Broker Initialization ---
def initialize_broker():
    """Initializes the correct broker based on market status."""
    with state_lock:
        settings = app_state["settings"]
        is_open = utils.is_market_open()
        
        if is_open:
            log_action("Market is OPEN. Initializing Zerodha broker.")
            if settings.get("api_key") and settings.get("api_secret"):
                try:
                    app_state["broker_instance"] = broker.ZerodhaKiteBroker(
                        api_key=settings["api_key"],
                        secret=settings["api_secret"]
                    )
                    # Fetch real wallet balance
                    app_state["portfolio"]["wallet"] = app_state["broker_instance"].get_wallet_balance()
                    log_action(f"Zerodha Broker initialized. Wallet: ₹{app_state['portfolio']['wallet']:.2f}")
                except Exception as e:
                    log_action(f"ERROR: Failed to initialize Zerodha Kite Broker: {e}")
                    log_action("Falling back to Paper Broker.")
                    app_state["broker_instance"] = broker.PaperBroker()
            else:
                log_action("WARNING: Zerodha credentials not set. Falling back to Paper Broker.")
                app_state["broker_instance"] = broker.PaperBroker()
        else:
            log_action("Market is CLOSED. Initializing Paper Broker for simulation.")
            app_state["broker_instance"] = broker.PaperBroker()

# --- Core Trading Logic (Auto Loop) ---
def auto_loop():
    """The main automated trading loop running in a background thread."""
    log_action("Auto trading loop thread started.")
    while True:
        try:
            with state_lock:
                settings = app_state["settings"]
                is_enabled = settings.get("auto_trading_enabled", False)
                broker_inst = app_state["broker_instance"]
                positions = app_state["portfolio"]["positions"]

            if not is_enabled or not broker_inst:
                time.sleep(5)
                continue

            # --- 1. Track Existing Positions ---
            if positions:
                current_position = positions[0] # Simple: one position at a time
                ltp = broker_inst.get_ltp(current_position.symbol)
                
                if ltp is not None:
                    current_position.update_ltp(ltp)
                    # Check for exit
                    if should_exit(ltp, current_position.sl, current_position.tp):
                        log_action(f"EXIT SIGNAL for {current_position.symbol} at LTP {ltp}.")
                        broker_inst.close_position(current_position)
                        # Position will be removed from state by the broker's close method
                time.sleep(5) # Quicker check for exits
                continue # Skip new scans if we are in a position

            # --- 2. Scan for New Opportunities ---
            log_action("Scanning for new trade candidates...")
            wallet_balance = broker_inst.get_wallet_balance()
            
            # Zerodha creds are needed for scanning even in paper mode
            api_key = settings.get("api_key")
            api_secret = settings.get("api_secret")

            if not api_key or not api_secret:
                log_action("Cannot scan: Zerodha API credentials are required.")
                time.sleep(60)
                continue

            try:
                candidates = scanner.top10_buy_candidates(api_key, api_secret, wallet_balance)
                with state_lock:
                    app_state["candidates"] = [c.to_dict() for c in candidates]
                if not candidates:
                    log_action("No suitable candidates found in this scan.")
            except Exception as e:
                log_action(f"ERROR during scan: {e}")
                with state_lock:
                    app_state["candidates"] = []

            # --- 3. Select & Buy ---
            if candidates:
                top_candidate = candidates[0]
                log_action(f"Top candidate found: {top_candidate.symbol} with score {top_candidate.meta['score']:.2f}")
                
                try:
                    sl, tp = calc_sl_tp(top_candidate.ltp)
                    order_hint = (
                        f"Paper trade based on EOD data." 
                        if not utils.is_market_open() else 
                        f"Live trade based on score {top_candidate.meta['score']:.2f}"
                    )
                    
                    order = broker.Order(
                        symbol=top_candidate.symbol,
                        qty=top_candidate.meta['affordable_qty'],
                        side='BUY',
                        sl=sl,
                        tp=tp,
                        hint=order_hint
                    )
                    log_action(f"Placing order for {order.qty} of {order.symbol}...")
                    broker_inst.place_order(order)
                    # The broker instance will update the global state with the new position
                except Exception as e:
                    log_action(f"ERROR placing order for {top_candidate.symbol}: {e}")

            # --- Wait for next cycle ---
            log_action("Scan cycle complete. Waiting for the next minute.")
            time.sleep(60)

        except Exception as e:
            log_action(f"CRITICAL ERROR in auto_loop: {e}")
            time.sleep(60)


# --- WebSocket Handling ---
@sock.route('/ws/live')
def live_data_feed(ws):
    """Pushes the current app state to connected clients."""
    log_action("WebSocket client connected.")
    try:
        while True:
            with state_lock:
                # Create a deep copy to send
                data_to_send = {
                    "settings": app_state["settings"],
                    "health": app_state["health"],
                    "portfolio": {
                        "wallet": app_state["portfolio"]["wallet"],
                        "positions": [p.to_dict() for p in app_state["portfolio"]["positions"]]
                    },
                    "candidates": app_state["candidates"],
                    "logs": app_state["logs"][:15] # Send recent 15 logs
                }
            ws.send(json.dumps(data_to_send, default=str))
            time.sleep(2)  # Update frequency
    except Exception as e:
        log_action(f"WebSocket client disconnected or error: {e}")


# --- HTTP Routes ---
@app.route('/')
def index():
    """Renders the main dashboard UI."""
    return render_template('index.html')

@app.route('/api/settings', methods=['POST'])
def update_settings():
    """Receives and saves new settings."""
    data = request.json
    with state_lock:
        app_state["settings"]["api_key"] = data.get("apiKey", "")
        app_state["settings"]["api_secret"] = data.get("apiSecret", "")
        save_settings(app_state["settings"])
        log_action("Settings updated. Re-initializing broker.")
    
    # Re-initialize broker with new settings
    threading.Thread(target=initialize_broker).start()
    
    return jsonify({"status": "success", "message": "Settings updated."})

@app.route('/api/auto_toggle', methods=['POST'])
def auto_toggle():
    """Toggles the auto trading loop on or off."""
    with state_lock:
        is_enabled = app_state["settings"].get("auto_trading_enabled", False)
        app_state["settings"]["auto_trading_enabled"] = not is_enabled
        save_settings(app_state["settings"])
        status = "ENABLED" if not is_enabled else "DISABLED"
        log_action(f"Auto trading has been {status}.")
    return jsonify({"status": "success", "auto_trading_enabled": not is_enabled})

@app.route('/api/health')
def health_check():
    """Returns the current health status of the application."""
    with state_lock:
        app_state["health"]["last_update"] = datetime.now().isoformat()
        # More sophisticated checks can be added here
        app_state["health"]["status"] = "ok" if app_state["broker_instance"] else "broker_not_initialized"
        return jsonify(app_state["health"])

# --- App Initialization ---
if __name__ == '__main__':
    # Load initial settings
    with state_lock:
        app_state["settings"] = load_settings()

    # Initialize broker in a separate thread to not block startup
    threading.Thread(target=initialize_broker).start()

    # Start the main trading loop in a background thread
    trading_thread = threading.Thread(target=auto_loop, daemon=True)
    trading_thread.start()

    log_action("Flask application starting.")
    # Note: In a production environment, use a proper WSGI server like Gunicorn or uWSGI
    app.run(host='0.0.0.0', port=5000, debug=False)
