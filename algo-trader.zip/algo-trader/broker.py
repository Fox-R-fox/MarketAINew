import logging
from abc import ABC, abstractmethod
from kiteconnect import KiteConnect
import time

# Import the global state and lock from the main app
# This is a common pattern for smaller Flask apps to share state.
# For larger apps, consider using Flask's 'g' object or a dedicated state management library.
from app import app_state, state_lock, log_action

# --- Data Models ---
class Position:
    """Represents an open trading position."""
    def __init__(self, symbol, qty, entry_price, side, sl, tp, order_id):
        self.symbol = symbol
        self.qty = qty
        self.entry_price = entry_price
        self.side = side
        self.sl = sl
        self.tp = tp
        self.order_id = order_id
        self.ltp = entry_price
        self.pnl = 0.0

    def update_ltp(self, ltp):
        """Updates the last traded price and recalculates P&L."""
        self.ltp = ltp
        if self.side == 'BUY':
            self.pnl = (self.ltp - self.entry_price) * self.qty
        else: # SELL
            self.pnl = (self.entry_price - self.ltp) * self.qty
            
    def to_dict(self):
        return self.__dict__

class Order:
    """Represents a request to place an order."""
    def __init__(self, symbol, qty, side, sl, tp, hint=""):
        self.symbol = symbol
        self.qty = qty
        self.side = side.upper()
        self.sl = sl
        self.tp = tp
        self.hint = hint

# --- Broker Interface (Abstract Base Class) ---
class Broker(ABC):
    @abstractmethod
    def place_order(self, order: Order):
        pass

    @abstractmethod
    def close_position(self, position: Position):
        pass
    
    @abstractmethod
    def get_ltp(self, symbol: str):
        pass

    @abstractmethod
    def get_wallet_balance(self):
        pass

# --- Concrete Implementations ---
class PaperBroker(Broker):
    """A broker for paper trading and simulation."""
    def __init__(self, initial_wallet=50000):
        with state_lock:
            app_state["portfolio"]["wallet"] = initial_wallet
            app_state["portfolio"]["positions"] = []

    def place_order(self, order: Order):
        with state_lock:
            wallet = app_state["portfolio"]["wallet"]
            # To simulate a fill, we need a price. In market-closed simulation,
            # this comes from the scanner's last fetched EOD data.
            candidate = next((c for c in app_state["candidates"] if c['symbol'] == order.symbol), None)
            
            if not candidate:
                log_action(f"PAPER: Could not find price for {order.symbol} to fill order. Rejecting.")
                return

            entry_price = candidate['ltp']
            required_margin = entry_price * order.qty
            
            if wallet < required_margin:
                log_action(f"PAPER: Insufficient funds to buy {order.qty} of {order.symbol}. Required: {required_margin}, Wallet: {wallet}")
                return

            app_state["portfolio"]["wallet"] -= required_margin
            
            new_position = Position(
                symbol=order.symbol,
                qty=order.qty,
                entry_price=entry_price,
                side=order.side,
                sl=order.sl,
                tp=order.tp,
                order_id=f"paper_{int(time.time())}"
            )
            app_state["portfolio"]["positions"].append(new_position)
            log_action(f"PAPER: Successfully placed BUY order for {order.qty} of {order.symbol} at {entry_price:.2f}")

    def close_position(self, position: Position):
        with state_lock:
            # Find the position in the global state
            pos_to_close = next((p for p in app_state["portfolio"]["positions"] if p.symbol == position.symbol), None)
            
            if not pos_to_close:
                log_action(f"PAPER: Could not find position for {position.symbol} to close.")
                return

            # Simulate closing at the last known LTP
            exit_price = pos_to_close.ltp
            pnl = pos_to_close.pnl
            
            app_state["portfolio"]["wallet"] += (pos_to_close.entry_price * pos_to_close.qty) + pnl
            app_state["portfolio"]["positions"].remove(pos_to_close)
            log_action(f"PAPER: Successfully closed position for {pos_to_close.symbol} at {exit_price:.2f}. P&L: {pnl:.2f}")

    def get_ltp(self, symbol: str):
        # In paper mode, we can't get real-time LTP. We simulate by using the last scanned price.
        # For a more advanced simulation, one could introduce a random walk or use historical data.
        with state_lock:
            position = next((p for p in app_state["portfolio"]["positions"] if p.symbol == symbol), None)
            # To make P&L static after entry in paper mode (as there's no live tick)
            return position.entry_price if position else 0

    def get_wallet_balance(self):
        with state_lock:
            return app_state["portfolio"]["wallet"]

class ZerodhaKiteBroker(Broker):
    """The broker for live trading with Zerodha Kite."""
    def __init__(self, api_key, secret):
        self.kite = KiteConnect(api_key=api_key)
        # In a real app, you would complete the login flow here.
        # For this example, we assume the access token is generated and available.
        # self.kite.set_access_token("YOUR_ACCESS_TOKEN") # This would be part of a login flow UI
        log_action("Zerodha Broker needs manual login to get access token. Functionality is simulated.")
        self.api_key = api_key # Store for LTP fetching
        self.api_secret = secret # Store for LTP fetching

    def place_order(self, order: Order):
        log_action(f"ZERODHA (SIMULATED): Placing MARKET order for {order.qty} of {order.symbol}")
        # In a real implementation:
        # try:
        #     order_id = self.kite.place_order(
        #         variety=self.kite.VARIETY_REGULAR,
        #         exchange=self.kite.EXCHANGE_NFO,
        #         tradingsymbol=order.symbol,
        #         transaction_type=self.kite.TRANSACTION_TYPE_BUY if order.side == 'BUY' else self.kite.TRANSACTION_TYPE_SELL,
        #         quantity=order.qty,
        #         product=self.kite.PRODUCT_MIS,
        #         order_type=self.kite.ORDER_TYPE_MARKET,
        #     )
        #     log_action(f"ZERODHA: Successfully placed order. Order ID: {order_id}")
        #     # You would then need to fetch the order details to get the entry price
        #     # and create a Position object to add to the state.
        # except Exception as e:
        #     log_action(f"ZERODHA ERROR: {e}")

        # Simulate for this app, similar to paper trading
        with state_lock:
            # Use last known price to create position object
            candidate = next((c for c in app_state["candidates"] if c['symbol'] == order.symbol), None)
            if not candidate:
                log_action(f"ZERODHA (SIMULATED): Could not find LTP for {order.symbol}. Rejecting.")
                return

            new_position = Position(
                symbol=order.symbol, qty=order.qty, entry_price=candidate['ltp'],
                side=order.side, sl=order.sl, tp=order.tp, order_id=f"live_{int(time.time())}"
            )
            app_state["portfolio"]["positions"].append(new_position)

    def close_position(self, position: Position):
        log_action(f"ZERODHA (SIMULATED): Closing position for {position.symbol} with opposite MARKET order.")
        # In a real implementation:
        # try:
        #     order_id = self.kite.place_order(...) # Opposite transaction type
        #     log_action(f"ZERODHA: Successfully placed closing order. Order ID: {order_id}")
        # except Exception as e:
        #     log_action(f"ZERODHA ERROR closing position: {e}")

        # Simulate for this app
        with state_lock:
            pos_to_close = next((p for p in app_state["portfolio"]["positions"] if p.symbol == position.symbol), None)
            if pos_to_close:
                app_state["portfolio"]["positions"].remove(pos_to_close)
                log_action(f"ZERODHA (SIMULATED): Position for {position.symbol} closed.")


    def get_ltp(self, symbol: str):
        # This part cannot be fully simulated without a valid session.
        # We will reuse the scanner's logic for fetching quotes.
        from scanner import _get_kite_instance # avoid circular import
        try:
            kite_inst = _get_kite_instance(self.api_key, self.api_secret)
            quote = kite_inst.quote(f"NFO:{symbol}")
            if quote and f"NFO:{symbol}" in quote:
                return quote[f"NFO:{symbol}"]["last_price"]
        except Exception as e:
            log_action(f"ZERODHA: Could not fetch LTP for {symbol}: {e}")
        return None

    def get_wallet_balance(self):
        # In a real implementation:
        # try:
        #     margins = self.kite.margins()
        #     return margins['equity']['available']['cash']
        # except Exception as e:
        #     log_action(f"ZERODHA: Could not fetch wallet balance: {e}")
        #     return 0
        log_action("ZERODHA (SIMULATED): Fetching wallet balance.")
        # Return the last known wallet balance for simulation purposes
        with state_lock:
            return app_state["portfolio"]["wallet"]
