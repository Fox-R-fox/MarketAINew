Flask Algorithmic Trading Platform

This is a comprehensive algorithmic trading application built with Python and Flask. It provides a web-based dashboard to configure, run, and monitor an automated trading strategy for the F&O (Futures and Options) segment using Zerodha Kite APIs.

About The Project

This platform is designed for traders who want to automate their strategies in the Indian stock market. It intelligently determines the market's status (open or closed) and switches its trading mode accordingly. During live market hours, it can execute real trades through a Zerodha account. When the market is closed, it seamlessly transitions to a paper trading mode, allowing for strategy testing and simulation using the latest available data.

The core of the application is an automated loop that continuously scans for opportunities, selects the best candidate based on a scoring algorithm (enhanced by a placeholder AI/ML model), executes trades, tracks open positions, and closes them based on predefined stop-loss and take-profit rules.

Key Features

Hybrid Trading Modes: Automatically switches between live trading (via Zerodha Kite) during market hours and paper trading simulation when the market is closed.

Real-time Dashboard: A clean, single-page web UI that displays wallet balance, open positions, top trade candidates, and action logs, all updated in real-time using WebSockets.

Automated Strategy: Implements a full scan -> select -> buy -> track -> exit loop.

F&O Scanner: Scans thousands of NIFTY and BANKNIFTY options to find the top 10 candidates based on momentum indicators like Open Interest (OI) and price changes.

AI/ML Integration: Includes a placeholder for a machine learning model to enhance the candidate scoring process. A dummy model is provided to demonstrate the pipeline.

Secure Configuration: A settings panel on the UI to securely enter and save your Zerodha API credentials without hardcoding them.

Asynchronous & Responsive: The core trading logic runs in a background thread, ensuring the UI remains fast and responsive at all times.

Project Structure

algo-trader/
|
├── app.py              # Main Flask app, WebSocket, orchestrator
├── broker.py           # Zerodha and Paper trading logic
├── scanner.py          # F&O instrument scanner and ranker (with ML hook)
├── strategy.py         # Exit logic (SL/TP calculation)
├── utils.py            # Time, market open/close helpers
├── holidays.py         # Holiday checker
├── holidays.json       # List of market holidays
├── requirements.txt    # Python dependencies
├── model.pkl           # Dummy AI/ML model file
├── create_dummy_model.py # Script to generate the dummy model
|
├── static/
│   └── main.js         # Frontend JavaScript for WebSocket and UI updates
|
└── templates/
    └── index.html      # Main HTML file for the UI


Prerequisites

Before you begin, ensure you have the following:

Python 3.8 or higher: https://www.python.org/downloads/

Pip package manager: Usually comes with Python.

Zerodha Kite Developer Account: You will need an api_key and api_secret from the Kite Developer Console.

Installation

Clone the repository or download the source code.

Navigate to the project directory:

cd algo-trader


Install the required Python packages:
It is highly recommended to use a virtual environment.

# Create and activate a virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`

# Install dependencies
pip install -r requirements.txt


Generate the AI/ML Model:
The application requires a model file (model.pkl) to be present for the scanner to function. Run the provided script to generate a dummy model:

python create_dummy_model.py


This will create the model.pkl file in your project directory.

Running the Application

You can run the application using the built-in Flask development server for testing, but for a more stable experience, using a WSGI server like Gunicorn is recommended.

Development Mode

python app.py


The application will be available at http://127.0.0.1:5000.

Production Mode (Recommended)

Using Gunicorn with a gevent worker is necessary for WebSocket support.

gunicorn --worker-class geventwebsocket.gunicorn.workers.GeventWebSocketWorker --bind 0.0.0.0:8000 -w 1 app:app


The application will be available at http://127.0.0.1:8000.

How to Use

Start the application using one of the methods above.

Open your web browser and navigate to the appropriate URL.

Configure Settings: On the dashboard's "Settings" panel, enter your Zerodha api_key and api_secret. Click Save Settings. The backend will log that the settings have been updated and the broker is re-initializing.

Enable Auto Trading: Click the Enable Auto Trading button. The button will turn red to indicate it's active, and the system will begin the trading loop.

Monitor the Dashboard:

Action Logs: This panel shows a real-time feed of the bot's actions, such as "Scanning for new trade candidates..." or "Placing order for...".

Top 10 Candidates: This table will populate with potential trades found by the scanner, ranked by score.

Open Positions: When a trade is executed, it will appear here. The Last Traded Price (LTP) and Profit & Loss (P&L) will be updated periodically.

Portfolio: Your available funds are displayed here. In paper mode, this is a simulated wallet. In live mode, it will reflect your actual Zerodha balance.

Disable Auto Trading: To stop the bot from initiating new trades, click the Disable Auto Trading button. The bot will finish any current cycle but will not start a new scan until re-enabled.

Disclaimer: Algorithmic trading involves substantial financial risk and the possibility of capital loss. This application is provided for educational and demonstrational purposes only. It is not financial advice. You are solely responsible for any financial decisions you make. Test thoroughly in paper trading mode before considering any live deployment.